$(document).ready(function () {
    $('#profileTypeBtns > div').on('click', function () {
        location = $(this).attr('href');
    })
});